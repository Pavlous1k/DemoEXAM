namespace Drivers2.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Licenses
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        [Column("License date", TypeName = "date")]
        public DateTime? License_date { get; set; }

        [Column("Expire date", TypeName = "date")]
        public DateTime? Expire_date { get; set; }

        [StringLength(50)]
        public string Categories { get; set; }

        [Column("License series")]
        public string License_series { get; set; }

        [Column("license numbers")]
        public string license_numbers { get; set; }

        public string Status { get; set; }
    }
}
