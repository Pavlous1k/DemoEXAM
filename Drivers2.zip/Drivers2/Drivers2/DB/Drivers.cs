namespace Drivers2.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Drivers
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        public string Фамилия { get; set; }

        public string Имя { get; set; }

        public string Отчество { get; set; }

        [Column("Серия паспорта")]
        public int? Серия_паспорта { get; set; }

        [Column("Номер паспорта")]
        public int? Номер_паспорта { get; set; }

        [Column("Почтовый индекс")]
        public int? Почтовый_индекс { get; set; }

        [Column("Адрес регистрации")]
        public string Адрес_регистрации { get; set; }

        [Column("Адрес проживания")]
        public string Адрес_проживания { get; set; }

        [Column("Место работы")]
        public string Место_работы { get; set; }

        public string Должность { get; set; }

        [Column("Мобильный телефон")]
        [StringLength(50)]
        public string Мобильный_телефон { get; set; }

        public string Email { get; set; }

        public string Фотография { get; set; }

        public string Замечания { get; set; }
    }
}
