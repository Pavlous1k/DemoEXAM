namespace Drivers2.DB
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.DataAnnotations;
    using System.ComponentModel.DataAnnotations.Schema;
    using System.Data.Entity.Spatial;

    public partial class Cars
    {
        [DatabaseGenerated(DatabaseGeneratedOption.None)]
        public int ID { get; set; }

        public string VIN { get; set; }

        public string Manufacturer { get; set; }

        public string Model { get; set; }

        public int? Year { get; set; }

        public int? Weight { get; set; }

        public int? Color { get; set; }

        [Column("Engine type")]
        public int? Engine_type { get; set; }

        [Column("Type of drive")]
        public string Type_of_drive { get; set; }
    }
}
