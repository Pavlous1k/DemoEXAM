﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Drivers2.DB;

namespace Drivers2
{
    public partial class Cars : Form
    {
        Model1 db = new Model1();
        public Cars()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
            Main frm = new Main();
            frm.Show();
        }

        private void Cars_Load(object sender, EventArgs e)
        {
            carsBindingSource.DataSource = db.Cars.ToList();
        }
    }
}
